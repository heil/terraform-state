# README

 - pip install "pywinrm>=0.2.2"
 - xfreerdp  /u:'Terraform' /p:'Toh~nos2shad' /w:1900 /h:1000 /v:18.193.114.149 /drive:floppy,/home/heil/Downloads
